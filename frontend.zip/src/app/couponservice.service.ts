import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { Coupon } from './coupon';


@Injectable({
  providedIn: 'root'
})
export class CouponserviceService {

  _url = "http://localhost:8080/coupons";
  messageSuccess: boolean | undefined;
  
  constructor(private _http:HttpClient) { }

  public add(c:Coupon){
    console.log(c);
    console.log(JSON.stringify(c));
    var cal =  this._http.post(this._url+"/add",c, { observe: 'response', responseType: 'text'}).subscribe();
   
  }

  public get(){
      var our =  this._http.get(this._url+"/list");
      console.log(our);
      return our;
  }

  public deleteCoupon(ID:String){
    console.log(this._url+"/delete/"+ID);
    var our =  this._http.delete(this._url+"/delete/"+ID);
    console.log(our);
    return our;
  }
}
