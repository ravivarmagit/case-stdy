import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { CouponserviceService } from '../couponservice.service';


@Component({
  selector: 'app-admin-deals-add',
  templateUrl: './admin-deals-add.component.html',
  styleUrls: ['./admin-deals-add.component.css']
})
export class AdminDealsAddComponent implements OnInit {

  public categories = ["Mobiles","Laptop","Fashion","Food","Furniture"]

  public adForm!: FormGroup;
  public submitted = false;
  public confirmed = false;

  constructor(private _fb:FormBuilder, private formservice:CouponserviceService) { }

  ngOnInit(): void  {
    
    //creating form group and assigning form control
    this.adForm = this._fb.group({
      provider:["",[Validators.required]],
      code:["",[Validators.required]],
      category:["",[Validators.required]],
      description:["",[Validators.required]]
    });
  }
 
  
  //making submit to enable confirmation page
  onsubmit(){
    this.submitted = true;
    // console.log("-----------------");
    // console.log(this.adForm.value);
    // console.log("-----------------");
  }

  //pushing data to array in advertisement Service
  confirm(){
    this.confirmed = true;
    //var newcoupon = new coupon("Snapdeal","opvxd5","Mobiles","15% Off on all mobiles");
    this.formservice.add(this.adForm.value);
  }

  //canceling on confirmation page
  cancel(){
    this.submitted = false;
  }

}
