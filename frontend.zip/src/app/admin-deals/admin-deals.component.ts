import { Component, OnInit } from '@angular/core';
import { CouponserviceService } from '../couponservice.service';

@Component({
  selector: 'app-admin-deals',
  templateUrl: './admin-deals.component.html',
  styleUrls: ['./admin-deals.component.css']
})
export class AdminDealsComponent implements OnInit {
   public ListOfCoupons:any = [];
  constructor(private couponservice:CouponserviceService) { }

  ngOnInit(): void {this.couponservice.get().subscribe(response=>{
    this.ListOfCoupons = response;
    //console.log(JSON.stringify(response));
    console.log(this.ListOfCoupons);
  },
  error=>{
    console.log(error)
  })
}
get(){
  this.couponservice.get().subscribe(response=>{
    this.ListOfCoupons = response;
    //console.log(JSON.stringify(response));
    console.log(this.ListOfCoupons);
  },
  error=>{
    console.log(error)
  })
}

delete(ID:String,i:number){
  console.log(ID);
  this.couponservice.deleteCoupon(ID).subscribe();
  this.ListOfCoupons.splice(i,1);
  //window.location.reload();
}

}
