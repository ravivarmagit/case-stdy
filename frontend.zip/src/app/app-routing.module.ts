import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDealsAddComponent } from './admin-deals-add/admin-deals-add.component';
import { AdminDealsComponent } from './admin-deals/admin-deals.component';
import { AdminComponent } from './admin/admin.component';
import { CouponsComponent } from './coupons/coupons.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path: 'adminDealsAdd', component:AdminDealsAddComponent},
  {path: 'adminDeals', component:AdminDealsComponent},
  {path: 'home', component:HomeComponent},
  {path: 'admin', component:AdminComponent},
  {path: 'user', component:UserComponent},
  {path: 'coupons', component:CouponsComponent},
  {path:'',component:HomeComponent, pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
