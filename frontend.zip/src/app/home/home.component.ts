import { Component, OnInit } from '@angular/core';
import { CouponserviceService } from '../couponservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public ListOfCoupons:any = [];

  constructor(private couponservice: CouponserviceService) { }

  ngOnInit(): void {
    this.couponservice.get().subscribe(response=>{
      this.ListOfCoupons = response;
      console.log(this.ListOfCoupons);
  },
  error=>{
    console.log(error)
  })
}
  public getImg(provider:String){
    return "assets/images/provider/"+provider+".png";
}
}